package controllers;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import javafx.scene.layout.BorderPane;

/**
 * FXML Controller class
 *
 * @author gettsu
 */
public class FXMLsecundaryController implements Initializable {

    /**
     * Initializes the controller class.
     */
    @FXML
    private Label fxName;
    
    private String login;

    public String getLogin() {
        return login;
    }

    public void setLogin(String login) {
        this.login = login;
        fxName.setText("Welcome " + login);
    }

    @Override
    public void initialize(URL url, ResourceBundle rb) {

        fxName.setText("welcome " + login);
        // TODO
    }

}
