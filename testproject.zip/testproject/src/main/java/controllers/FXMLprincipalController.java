package controllers;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.control.MenuBar;
import javafx.scene.control.MenuItem;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.BorderPane;

/**
 * FXML Controller class
 *
 * @author gettsu
 */
public class FXMLprincipalController implements Initializable {

    /**
     * Initializes the controller class.
     */
    @FXML
    private BorderPane fxRoot;
 
    private AnchorPane fxSecundary;
    
    @FXML
    private MenuBar fxMenu;
    private FXMLsecundaryController secundaryController;
    private AnchorPane fxLogin;
    private FXMLLoginController loginController;
    private String usuario;

    public String getUsuario() {
        return usuario;
    }

    public void setUsuario(String usuario) {
        this.usuario = usuario;
    }

    @FXML
    public void cargarSecundary() {
        fxMenu.setVisible(true);
        fxRoot.setCenter(fxSecundary);
        secundaryController.setLogin(this.getUsuario());
        
    }

    @FXML
    public void cargarLogin() {
        fxRoot.setCenter(fxLogin);

    }

    public void precargarSecundary() {
        try {
            FXMLLoader loaderMenu = new FXMLLoader(
                    getClass().getResource(
                            "/fxml/FXMLsecundary.fxml"));
            fxSecundary = loaderMenu.load();
            secundaryController
                    = loaderMenu.getController();

        } catch (IOException ex) {

            Logger.getLogger(FXMLprincipalController.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

    public void precargarLogin() {
        try {
            FXMLLoader loaderMenu = new FXMLLoader(
                    getClass().getResource(
                            "/FXML/FXMLLogin.fxml"));
            fxLogin = loaderMenu.load();
            loginController
                    = loaderMenu.getController();
            loginController.setPrincipalController(this);

        } catch (IOException ex) {

            Logger.getLogger(FXMLprincipalController.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

    @FXML
    public void sout() {
        System.out.println("hola mundo");
    }

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        precargarSecundary();
        precargarLogin();
        fxMenu.setVisible(false);
        cargarLogin();
        

    }

}
